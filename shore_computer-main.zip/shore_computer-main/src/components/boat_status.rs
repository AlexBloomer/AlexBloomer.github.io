use std::time::Instant;

use color_eyre::{eyre::Result, owo_colors::OwoColorize};
use ratatui::{prelude::*, widgets::*};

use super::Component;
use crate::{
  action::{Action, FromBoatAction, ToBoatAction},
  tui::Frame,
};

#[derive(Debug, Clone, PartialEq)]
pub struct BoatStatus {
  enabled: bool,
  confirmed: bool,
}

impl Default for BoatStatus {
  fn default() -> Self {
    Self::new()
  }
}

impl BoatStatus {
  pub fn new() -> Self {
    Self { enabled: false, confirmed: true }
  }

  fn app_tick(&mut self) -> Result<()> {
    Ok(())
  }

  fn render_tick(&mut self) -> Result<()> {
    Ok(())
  }
}

impl Component for BoatStatus {
  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    match action {
      Action::Tick => self.app_tick()?,
      Action::Render => self.render_tick()?,
      Action::ToBoat(ToBoatAction::ControlStatusChange(status)) => {
        self.enabled = status;
        self.confirmed = false;
      },
      Action::FromBoat(FromBoatAction::ControlStatusChange(status)) => {
        self.enabled = status;
        self.confirmed = true;
      },
      _ => {},
    }

    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    let rects = Layout::default()
      .direction(Direction::Vertical)
      .constraints(vec![
        Constraint::Percentage(100), // first row
        Constraint::Min(3),
      ])
      .split(rect);

    let bottom_area = Layout::default()
      .direction(Direction::Horizontal)
      .constraints(vec![
        Constraint::Percentage(80), // first row
        Constraint::Percentage(20),
      ])
      .split(rects[1]);

    let block_border_style = if self.confirmed {
      if self.enabled {
        Style::default().red()
      } else {
        Style::default().green()
      }
    } else {
      Style::default().yellow()
    };

    let block = Block::default()
      .title(block::Title::from("Control Status".white()).alignment(Alignment::Left))
      .border_type(BorderType::Rounded)
      .borders(Borders::ALL)
      .border_style(block_border_style);

    let estop_text = if !self.enabled && self.confirmed {
      Paragraph::new("Disabled (Safe)").white().on_green().centered()
    } else if !self.enabled && !self.confirmed {
      Paragraph::new("REQUESTED Disable...").yellow().on_yellow().centered()
    } else if self.enabled && !self.confirmed {
      Paragraph::new("REQUESTED Enable...").yellow().on_yellow().centered()
    } else {
      Paragraph::new("Enabled").white().on_red().centered()
    };

    f.render_widget(&block, bottom_area[1]);
    f.render_widget(estop_text, block.inner(bottom_area[1]));
    Ok(())
  }
}

#[cfg(test)]
mod tests {
  use pretty_assertions::assert_eq;

  use super::*;

  #[test]
  fn test_safety_by_default() {
    let mut boat_status = BoatStatus::new();
    assert_eq!(boat_status.enabled, false);

    assert_eq!(boat_status.update(Action::FromBoat(FromBoatAction::ControlStatusChange(false))).unwrap(), None);

    assert_eq!(boat_status.enabled, false);
  }

  #[test]
  fn test_basic_on_off() {
    let mut boat_status = BoatStatus::new();
    assert_eq!(boat_status.enabled, false);

    assert_eq!(boat_status.update(Action::FromBoat(FromBoatAction::ControlStatusChange(true))).unwrap(), None);

    assert_eq!(boat_status.enabled, true);

    assert_eq!(boat_status.update(Action::FromBoat(FromBoatAction::ControlStatusChange(false))).unwrap(), None);

    assert_eq!(boat_status.enabled, false);
  }
}
