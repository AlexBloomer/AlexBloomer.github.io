use std::{collections::HashMap, time::Duration};

use color_eyre::{eyre::Result, owo_colors::OwoColorize};
use crossterm::event::{KeyCode, KeyEvent};
use ratatui::{prelude::*, widgets::*};
use serde::{Deserialize, Serialize};
use shore_computer::radio_comms::MotorSetRequest;
use tokio::sync::mpsc::UnboundedSender;

use super::{Component, Frame};
use crate::{
  action::{Action, FromBoatAction, ToBoatAction},
  config::{Config, KeyBindings},
};

pub struct SetMotors {
  command_tx: Option<UnboundedSender<Action>>,
  config: Config,
  left_power: u32,
  right_power: u32,
  confirmed: bool,
  enabled: bool,
}

impl Default for SetMotors {
  fn default() -> Self {
    Self {
      command_tx: Default::default(),
      config: Default::default(),
      left_power: Default::default(),
      right_power: Default::default(),
      confirmed: true,
      enabled: Default::default(),
    }
  }
}

impl SetMotors {
  pub fn new() -> Self {
    Self::default()
  }
}

impl Component for SetMotors {
  fn register_action_handler(&mut self, tx: UnboundedSender<Action>) -> Result<()> {
    self.command_tx = Some(tx);
    Ok(())
  }

  fn register_config_handler(&mut self, config: Config) -> Result<()> {
    self.config = config;
    Ok(())
  }

  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    match action {
      Action::Tick => {},
      Action::RelativeMotorSpeed(left, right) => {
        self.left_power = self.left_power.saturating_add_signed(left).min(100);
        self.right_power = self.right_power.saturating_add_signed(right).min(100);
        self.confirmed = false;
        return Ok(Some(Action::ToBoat(ToBoatAction::SetMotor(
          self.left_power as f32 / 100.0,
          self.right_power as f32 / 100.0,
        ))));
      },
      Action::FromBoat(FromBoatAction::SetMotor(left, right)) => {
        self.left_power = (left * 100.0) as u32;
        self.right_power = (right * 100.0) as u32;
        self.confirmed = true;
      },
      Action::FromBoat(FromBoatAction::ControlStatusChange(enabled)) => {
        self.enabled = enabled;
      },
      _ => {},
    }
    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    let rects = Layout::default()
      .direction(Direction::Vertical)
      .constraints(vec![
        Constraint::Percentage(100), // first row
        Constraint::Min(3),
      ])
      .split(rect);

    let innner_rect = Layout::default()
        .direction(Direction::Vertical)
        .constraints(vec![
            Constraint::Fill(1),
            Constraint::Fill(1),
            Constraint::Fill(1),
        ])
        .split(rects[0]);

    let p = Paragraph::new(format!(" Desired Motor Speed: {}% | {}% ", self.left_power, self.right_power))
      .alignment(Alignment::Center);

    let p = if self.confirmed { p.style(Style::new().fg(Color::Green)) } else { p.style(Style::new().fg(Color::Red)) };

    f.render_widget(p, innner_rect[1]);

    Ok(())
  }
}
