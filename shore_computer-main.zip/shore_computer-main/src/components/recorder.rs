use std::{
  collections::HashMap,
  path::PathBuf,
  time::{Duration, SystemTime},
};

use color_eyre::eyre::Result;
use crossterm::event::{KeyCode, KeyEvent};
use ratatui::{prelude::*, widgets::*};
use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use tokio::sync::mpsc::UnboundedSender;
use tracing::info;

use super::{Component, Frame};
use crate::{
  action::Action,
  config::{Config, KeyBindings},
};

#[derive(Default)]
pub struct Recorder {
  command_tx: Option<UnboundedSender<Action>>,
  config: Config,
  db_conn: Option<Connection>,
}

impl Recorder {
  pub fn new() -> Self {
    Self::default()
  }
}

impl Component for Recorder {
  fn register_action_handler(&mut self, tx: UnboundedSender<Action>) -> Result<()> {
    self.command_tx = Some(tx);
    Ok(())
  }

  fn register_config_handler(&mut self, config: Config) -> Result<()> {
    self.config = config;
    let db_target_path: PathBuf = [&self.config.config._data_dir, &self.config.config.db_path].iter().collect();
    self.db_conn =
      Some(Connection::open(&db_target_path).expect(&format!("We can write to db at: {db_target_path:?}")));
    info!("DB initialized!");

    self.db_conn.as_mut().expect("Just initialized conn").execute_batch(
      "CREATE TABLE IF NOT EXISTS to_boat_command_history (
            id        INTEGER PRIMARY KEY,
            timestamp DATETIME DEFAULT(STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')),
            command   TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS from_boat_command_history (
            id        INTEGER PRIMARY KEY,
            timestamp DATETIME DEFAULT(STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')),
            command   TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS shore_history (
          id        INTEGER PRIMARY KEY,
          timestamp DATETIME DEFAULT(STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')),
          command   TEXT NOT NULL
      )",
    )?;

    self
      .db_conn
      .as_mut()
      .expect("Just initialized conn")
      .execute("INSERT INTO shore_history (command) VALUES ('Startup')", ())?;

    Ok(())
  }

  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    let conn = self.db_conn.as_ref().expect("We initialized db");

    match action {
      Action::ToBoat(to_boat_action) => {
        conn.execute("INSERT INTO to_boat_command_history (command) VALUES (?1)", params![format!(
          "{to_boat_action:?}"
        )])?;
      },

      Action::FromBoat(from_boat_action) => {
        conn.execute("INSERT INTO from_boat_command_history (command) VALUES (?1)", params![format!(
          "{from_boat_action:?}"
        )])?;
      },
      Action::ConfirmQuit => {
        conn.execute("INSERT INTO shore_history (command) VALUES ('Shutdown')", ())?;
      },
      Action::CriticalError(error) => {
        conn.execute("INSERT INTO shore_history (command) VALUES (?1)", params![format!("Error: {error}")])?;
      },
      _ => {},
    }

    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, area: Rect) -> Result<()> {
    Ok(())
  }
}
