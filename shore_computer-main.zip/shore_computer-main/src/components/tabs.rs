use std::{collections::HashMap, time::Duration};

use color_eyre::eyre::Result;
use crossterm::event::{KeyCode, KeyEvent};
use ratatui::{prelude::*, widgets::*};
use serde::{Deserialize, Serialize};
use tokio::sync::mpsc::UnboundedSender;

use super::{Component, Frame};
use crate::{
  action::Action,
  config::{Config, KeyBindings},
};

#[derive(Default)]
pub struct SCTabs {
  command_tx: Option<UnboundedSender<Action>>,
  config: Config,
}

impl SCTabs {
  pub fn new() -> Self {
    Self::default()
  }
}

impl Component for SCTabs {
  fn register_action_handler(&mut self, tx: UnboundedSender<Action>) -> Result<()> {
    self.command_tx = Some(tx);
    Ok(())
  }

  fn register_config_handler(&mut self, config: Config) -> Result<()> {
    self.config = config;
    Ok(())
  }

  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    match action {
      Action::Tick => {},
      _ => {},
    }
    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    let rects = Layout::default()
      .direction(Direction::Vertical)
      .constraints(vec![
        Constraint::Percentage(100), // first row
        Constraint::Min(3),
      ])
      .split(rect);

    let tabs = Tabs::new(vec!["Tab1", "Tab2", "Tab3", "Tab4"])
      .block(Block::default().title("Tabs").borders(Borders::ALL).white())
      .style(Style::default().white())
      .highlight_style(Style::default().yellow())
      .select(2)
      .divider(symbols::line::VERTICAL);
    f.render_widget(tabs, rects[0]);
    Ok(())
  }
}
