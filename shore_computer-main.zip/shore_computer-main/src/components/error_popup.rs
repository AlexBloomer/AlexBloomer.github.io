use std::{collections::VecDeque, time::Instant};

use color_eyre::{eyre::Result, owo_colors::OwoColorize};
use ratatui::{prelude::*, widgets::*};

use super::Component;
use crate::{action::Action, tui::Frame};

#[derive(Debug, Clone, PartialEq)]
pub struct ErrorPopup {
  text: VecDeque<String>,
}

impl Default for ErrorPopup {
  fn default() -> Self {
    Self::new()
  }
}

impl ErrorPopup {
  pub fn new() -> Self {
    Self { text: VecDeque::new() }
  }
}

impl Component for ErrorPopup {
  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    match action {
      Action::CriticalError(error) => {
        self.text.push_back(error);
      },
      Action::DismissError => {
        self.text.pop_front();
      },
      _ => {},
    }

    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    if let Some(error_text) = &self.text.get(0) {
      let rects = Layout::default()
        .direction(Direction::Vertical)
        .constraints(vec![Constraint::Percentage(100), Constraint::Min(3)])
        .split(rect);

      let middle_top = Layout::default()
        .direction(Direction::Horizontal)
        .constraints(vec![Constraint::Ratio(1, 3); 3])
        .split(rects[0]);

      let top_rect = Layout::default()
        .direction(Direction::Vertical)
        .constraints(vec![Constraint::Fill(1), Constraint::Length(3), Constraint::Fill(1)])
        .split(middle_top[1]);

      let big_scary_block = Block::new().style(Style::new().bg(Color::White));

      let p = Paragraph::new(error_text.to_string())
        .block(
          Block::new().border_type(BorderType::Thick).border_style(Style::new().fg(Color::Red)).borders(Borders::ALL),
        )
        .style(Style::new().white().bg(Color::Red))
        .alignment(Alignment::Center);

      f.render_widget(&big_scary_block, rects[0]);
      f.render_widget(&p, top_rect[1]);
      if self.text.len() != 1 {
        f.render_widget(Paragraph::new(format!("1/{}", self.text.len())).alignment(Alignment::Right), top_rect[1])
      }
    }
    Ok(())
  }
}

#[cfg(test)]
mod tests {
  use pretty_assertions::assert_eq;

  use super::*;

  #[test]
  fn test_safety_by_default() {
    let mut error_popup = ErrorPopup::new();

    assert_eq!(error_popup.text, VecDeque::new());

    assert!(error_popup.update(Action::CriticalError("Don't die!".to_string())).is_ok());

    assert_eq!(error_popup.text, vec![("Don't die!".to_string())]);
  }
}
