use std::time::Duration;

use color_eyre::{eyre::Result, owo_colors::OwoColorize};
use ratatui::{prelude::*, widgets::*};
use tokio::{sync::mpsc::UnboundedSender, time::Instant};

use super::Component;
use crate::{
  action::{Action, FromBoatAction, ToBoatAction},
  tui::Frame,
};

const VIZ_LENGTH: usize = 10;

#[derive(Debug, Clone)]
pub struct Connection {
  connected: bool,
  last_ping: Option<Instant>,
  last_ping_response: Option<Instant>,
  command_tx: Option<UnboundedSender<Action>>,
  to_boat_viz: [bool; VIZ_LENGTH],
  from_boat_viz: [bool; VIZ_LENGTH],
  last_ping_visualization_update: Option<Instant>,
}

impl Default for Connection {
  fn default() -> Self {
    Self::new()
  }
}

impl Connection {
  pub fn new() -> Self {
    Self {
      connected: false,
      last_ping: None,
      command_tx: None,
      last_ping_response: None,
      from_boat_viz: [false; VIZ_LENGTH],
      to_boat_viz: [false; VIZ_LENGTH],
      last_ping_visualization_update: None,
    }
  }

  fn app_tick(&mut self) -> Result<()> {
    match self.last_ping {
      Some(last_time_time) => {
        if last_time_time.elapsed().as_secs() > 5 {
          self
            .command_tx
            .as_ref()
            .expect("Action handler is always registered")
            .send(Action::ToBoat(ToBoatAction::Ping))
            .expect("Channel never closed");
          self.last_ping = Some(Instant::now())
        }
      },
      None => {
        self
          .command_tx
          .as_ref()
          .expect("Action handler is always registered")
          .send(Action::ToBoat(ToBoatAction::Ping))
          .expect("Channel never closed");
        self.last_ping = Some(Instant::now())
      },
    }

    match self.last_ping_response {
      Some(last_ping_response_time) => {
        if last_ping_response_time.elapsed().as_secs() > 12 {
          self.connected = false;
        } else {
          self.connected = true;
        }
      },
      None => self.connected = false,
    }

    Ok(())
  }

  fn render_tick(&mut self) -> Result<()> {
    if let Some(last_ping_viz) = self.last_ping_visualization_update {
      if last_ping_viz.elapsed().as_millis() > 100 {
        self.to_boat_viz.rotate_right(1);
        self.from_boat_viz.rotate_right(1);
        self.to_boat_viz[0] = false;
        self.from_boat_viz[0] = false;
        self.last_ping_visualization_update = Some(Instant::now());
      }
    } else {
      self.to_boat_viz.rotate_right(1);
      self.from_boat_viz.rotate_right(1);
      self.to_boat_viz[0] = false;
      self.from_boat_viz[0] = false;
      self.last_ping_visualization_update = Some(Instant::now());
    }

    Ok(())
  }
}

impl Component for Connection {
  fn register_action_handler(&mut self, tx: UnboundedSender<Action>) -> Result<()> {
    self.command_tx = Some(tx);
    Ok(())
  }

  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    match action {
      Action::Tick => self.app_tick()?,
      Action::Render => self.render_tick()?,
      Action::FromBoat(from_boat) => {
        self.from_boat_viz[0] = true;
        if let FromBoatAction::Ping = from_boat {
          self.last_ping_response = Some(Instant::now());
          self.connected = true;
        }
      },
      Action::ToBoat(_) => {
        self.to_boat_viz[0] = true;
      },
      _ => {},
    }

    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    let rects = Layout::default()
      .direction(Direction::Vertical)
      .constraints(vec![
        Constraint::Percentage(100), // first row
        Constraint::Min(3),
      ])
      .split(rect);

    let bottom_area = Layout::default()
      .direction(Direction::Horizontal)
      .constraints(vec![
        Constraint::Percentage(80), // first row
        Constraint::Percentage(20),
      ])
      .split(rects[1]);

    let block = Block::default()
      .title(block::Title::from("Connection Status".white()).alignment(Alignment::Left))
      .border_type(BorderType::Rounded)
      .borders(Borders::ALL)
      .border_style(Style::default().white());

    let boat_viz: String = (0..VIZ_LENGTH)
      .into_iter()
      .map(|i| {
        if self.to_boat_viz[i] && self.from_boat_viz[VIZ_LENGTH - 1 - i] {
          return 'O';
        } else if self.to_boat_viz[i] {
          return ')';
        } else if self.from_boat_viz[VIZ_LENGTH - 1 - i] {
          return '(';
        }

        return ' ';
      })
      .collect();

    let connected_text = if self.connected {
      Paragraph::new(format!("Connected ✓     Shore |{boat_viz}| Boat")).green().centered()
    } else {
      let last_connected = match self.last_ping_response {
        Some(last_ping_time) => {
          humantime::format_duration(Duration::from_secs(last_ping_time.elapsed().as_secs())).to_string()
        },
        None => "Never".to_string(),
      };

      Paragraph::new(format!("Disconnected X     Last Connected: {last_connected} ago     Shore |{boat_viz}| Boat"))
        .red()
        .centered()
    };

    f.render_widget(&block, bottom_area[0]);
    f.render_widget(connected_text, block.inner(bottom_area[0]));
    Ok(())
  }
}
