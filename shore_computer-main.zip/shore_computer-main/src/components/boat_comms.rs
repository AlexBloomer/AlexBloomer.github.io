use std::{
  io::Cursor,
  process::exit,
  sync::{Arc, Mutex},
  thread::sleep,
  time::{Duration, Instant},
};

use color_eyre::{eyre::Result, owo_colors::OwoColorize};
use prost::Message;
use rand::Rng;
use ratatui::{prelude::*, widgets::*};
use serialport::{SerialPort, SerialPortBuilder};
use shore_computer::{
  dtp::{encode, try_decode},
  radio_comms::{
    self, to_boat_command, to_shore_response::Response, ControlStatusRequest, EchoRequest, EchoResponse,
    MotorSetRequest, ToBoatCommand, ToShoreResponse,
  },
  sliplib::{slip_encode, SlipDecoder},
};
use tokio::sync::mpsc::{self, UnboundedReceiver, UnboundedSender};
use tracing::{error, info};

use super::Component;
use crate::{
  action::{Action, FromBoatAction, ToBoatAction},
  config::Config,
  tui::Frame,
};

pub struct BoatComms {
  action_tx: Option<UnboundedSender<Action>>,
  quit_after_confirm: bool,
  serial_port: Option<Arc<Mutex<Box<dyn SerialPort>>>>,
  config: Option<Config>,
}

impl Default for BoatComms {
  fn default() -> Self {
    Self::new()
  }
}

impl BoatComms {
  pub fn new() -> Self {
    Self { action_tx: None, quit_after_confirm: false, config: None, serial_port: None }
  }

  fn app_tick(&mut self) -> Result<()> {
    Ok(())
  }

  fn render_tick(&mut self) -> Result<()> {
    Ok(())
  }

  fn send_serial(&mut self, data: &[u8]) {
    let tx = self.action_tx.clone().expect("Action handler is always registered");

    let data = slip_encode(data);

    match self.serial_port {
      Some(ref mut serial_port) => {
        let mut serial_port_result = serial_port.lock().expect("Other threads Won't panic while holding mutex");
        let serial_port = serial_port_result.as_mut();
        serial_port.write_all(&data).expect("Can write to Serial port");
        serial_port.flush().expect("Can flush serial port");
      },
      None => {
        tx.send(Action::CriticalError("Serial port not ready yet to send msg".to_string()))
          .expect("Channel never closed");
      },
    }
  }
}

impl Component for BoatComms {
  fn register_action_handler(&mut self, tx: UnboundedSender<Action>) -> Result<()> {
    self.action_tx = Some(tx);
    Ok(())
  }

  fn register_config_handler(&mut self, config: Config) -> Result<()> {
    self.config = Some(config.clone());

    let maybe_opened_serial_port =
      serialport::new(config.config.comm_port.clone(), 9600).timeout(Duration::from_millis(10)).open_native();
    let tx = self.action_tx.clone().expect("Channel always set");

    match maybe_opened_serial_port {
      Ok(port) => {
        self.serial_port = Some(Arc::new(Mutex::new(Box::new(port))));
        let serial_port_result = self.serial_port.as_ref().expect("We just set serial port").clone();

        tokio::spawn(async move {
          let mut buf = Vec::new();
          // let mut out_buf = Vec::new();
          let mut slip = SlipDecoder::new();

          info!("Listening on serial port...");

          loop {
            buf.clear();
            let result = {
              let mut serial_port_lock =
                serial_port_result.lock().expect("Other threads Won't panic while holding mutex");
              let serial_port = serial_port_lock.as_mut();
              serial_port.read_to_end(&mut buf)
            };
            if let false = buf.is_empty() {
              match slip.ingest(&buf) {
                Ok(packets) => {
                  for packet in packets {
                    if let Some(data) = try_decode(&packet) {
                      info!("Decoded packet: {:?}", data);
                      process_packet_data(&data, &tx);
                    } else {
                      error!("dtp packet decoding errored");
                    }
                  }
                },
                Err(slip_err) => {
                  error!("slip decoding returned error: {:?}", slip_err);
                },
              }
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
          }
        });
      },

      Err(error) => {
        info!("Comm port at \'{}\'", config.config.comm_port);
        self
          .action_tx
          .as_mut()
          .unwrap()
          .send(Action::CriticalError(format!("Unable to open Comm Port at {}", config.config.comm_port)))
          .expect("Can always send action");
      },
    };

    Ok(())
  }

  fn update(&mut self, action: Action) -> Result<Option<Action>> {
    let tx = self.action_tx.clone().expect("Action handler is always registered");
    match action {
      Action::Tick => self.app_tick()?,
      Action::Render => self.render_tick()?,
      Action::ToBoat(ToBoatAction::ControlStatusChange(new_status)) => {
        let quit_after_confirm = self.quit_after_confirm;

        let echo_request = ToBoatCommand{
          command: Some(to_boat_command::Command::ControlStatus(ControlStatusRequest { enabled: new_status }))
        };

        let protobuf_data = echo_request.encode_to_vec();
        let data = encode(&protobuf_data);

        self.send_serial(&data);
      },
      Action::RequestQuit => {
        self.quit_after_confirm = true;
        tx.send(Action::ToBoat(ToBoatAction::ControlStatusChange(false))).expect("Channel never closed");
      },

      Action::ToBoat(ToBoatAction::Ping) => {
          info!("Pinging boat...");

          let echo_request = ToBoatCommand{
            command: Some(to_boat_command::Command::Echo(EchoRequest {}))
          };

          let protobuf_data = echo_request.encode_to_vec();
          let data = encode(&protobuf_data);

          self.send_serial(&data);
      }

      Action::ToBoat(ToBoatAction::SetMotor(left, right)) => {
        let protobuf_data = ToBoatCommand{
          command: Some(to_boat_command::Command::SetMotor(MotorSetRequest {left_power: left, right_power: right}))
        }.encode_to_vec();
        let data = encode(&protobuf_data);

        self.send_serial(&data);
    }

      Action::FromBoat(FromBoatAction::ControlStatusChange(false)) => {
        if self.quit_after_confirm {
          tx.send(Action::ConfirmQuit).expect("Channel never closed");
        }
      }

      Action::Resize(_, _) // ignore other actions
      | Action::FromBoat(_)
      | Action::Suspend
      | Action::Resume
      | Action::ConfirmQuit
      | Action::Refresh
      | Action::Error(_)
      | Action::Help
      | Action::RelativeMotorSpeed(_, _)
      | Action::CriticalError(_)
      | Action::DismissError => {},
    }

    Ok(None)
  }

  fn draw(&mut self, f: &mut Frame<'_>, rect: Rect) -> Result<()> {
    Ok(())
  }
}
fn process_packet_data(data: &[u8], tx: &UnboundedSender<Action>) {
  match ToShoreResponse::decode(data) {
    Ok(msg) => {
      if let Some(response) = msg.response {
        match response {
          Response::Echo(_) => {
            tx.send(Action::FromBoat(FromBoatAction::Ping)).expect("Channel never closed");
          },
          Response::ControlStatus(new_status) => {
            tx.send(Action::FromBoat(FromBoatAction::ControlStatusChange(new_status.enabled)))
              .expect("Channel never closed");
          },
          Response::SetMotor(set_motor) => {
            tx.send(Action::FromBoat(FromBoatAction::SetMotor(set_motor.left_power, set_motor.right_power)))
              .expect("Channel never closed");
          },
        }
      }
    },
    Err(e) => error!("protobuf decode error: {}", e),
  }
}
