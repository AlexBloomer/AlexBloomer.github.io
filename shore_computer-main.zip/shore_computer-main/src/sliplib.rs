use std::collections::VecDeque;

use slip_codec::SlipError;

pub struct SlipDecoder {
  internal_in_buf: VecDeque<u8>,
  internal_out_buf: Vec<u8>,
  state: State,
}

const END: u8 = 0xC0;

/// SLIP escape token
const ESC: u8 = 0xDB;

/// SLIP escaped 0xC0 token
const ESC_END: u8 = 0xDC;

/// SLIP escaped 0xDB token
const ESC_ESC: u8 = 0xDD;


pub fn slip_encode(data: &[u8]) -> Vec<u8> {
  let mut out = Vec::new();
  out.push(END);

  for &byte in data {
    match byte {
      END => {
        out.push(ESC);
        out.push(ESC_END);
      },
      ESC => {
        out.push(ESC);
        out.push(ESC_ESC);
      },
      _ => {
        out.push(byte);
      },
    }
  }

  out.push(END);
  out
}
enum State {
  Normal,
  Error,
  Escape,
}

impl SlipDecoder {
  pub fn new() -> Self {
    Self { internal_in_buf: VecDeque::new(), internal_out_buf: Vec::new(), state: State::Normal }
  }

  pub fn ingest(&mut self, data: &[u8]) -> Result<Vec<Vec<u8>>, SlipError> {
    self.internal_in_buf.extend(data);
    let mut packets = Vec::new();

    loop {
      if let Some(packet) = self.try_decode()? {
        packets.push(packet);
      } else {
        return Ok(packets);
      }
    }
  }

  pub fn try_decode(&mut self) -> Result<Option<Vec<u8>>, SlipError> {
    while self.internal_in_buf.len() > 0 {
      let value = self.internal_in_buf.pop_front().expect("Internal buffer always has a value");

      match self.state {
        State::Normal => {
          match value {
            END => {
              if self.internal_out_buf.len() > 0 {
                let result = self.internal_out_buf.clone();
                self.internal_out_buf.clear();
                return Ok(Some(result));
              }
            },
            ESC => {
              self.state = State::Escape;
            },
            _ => {
              self.internal_out_buf.push(value);
            },
          }
        },
        State::Error => {
          if value == END {
            self.internal_out_buf.clear();
            self.state = State::Normal;
          }
        },
        State::Escape => {
          match value {
            ESC_END => {
              self.internal_out_buf.push(END);
              self.state = State::Normal;
            },
            ESC_ESC => {
              self.internal_out_buf.push(ESC);
              self.state = State::Normal;
            },
            _ => {
              self.state = State::Error;

              return Err(SlipError::FramingError);
            },
          }
        },
      }
    }

    return Ok(None);
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  #[test]
  fn empty_decode() {
    const INPUT: [u8; 2] = [0xc0, 0xc0];

    let mut slip = SlipDecoder::new();
    let res = slip.ingest(&mut INPUT.as_ref()).unwrap();
    assert_eq!(res.len(), 0);
  }

  #[test]
  fn simple_decode() {
    const INPUT: [u8; 7] = [0xc0, 0x01, 0x02, 0x03, 0x04, 0x05, 0xc0];
    const DATA: [u8; 5] = [0x01, 0x02, 0x03, 0x04, 0x05];

    let mut slip = SlipDecoder::new();
    let out = slip.ingest(&mut INPUT.as_ref()).unwrap();
    assert_eq!(out.len(), 1);
    assert_eq!(DATA, *out[0]);
  }

  /// Ensure that [ESC, ESC_END] -> [END]
  #[test]
  fn decode_esc_then_esc_end_sequence() {
    const INPUT: [u8; 6] = [0xc0, 0x01, 0xdb, 0xdc, 0x03, 0xc0];
    const DATA: [u8; 3] = [0x01, 0xc0, 0x03];

    let mut slip = SlipDecoder::new();
    let out = slip.ingest(&mut INPUT.as_ref()).unwrap();
    assert_eq!(out.len(), 1);
    assert_eq!(DATA, *out[0]);
  }

  /// Ensure that [ESC, ESC_ESC] -> [ESC]
  #[test]
  fn decode_esc_then_esc_esc_sequence() {
    const INPUT: [u8; 6] = [0xc0, 0x01, 0xdb, 0xdd, 0x03, 0xc0];
    const DATA: [u8; 3] = [0x01, 0xdb, 0x03];

    let mut slip = SlipDecoder::new();
    let out = slip.ingest(&mut INPUT.as_ref()).unwrap();
    assert_eq!(out.len(), 1);
    assert_eq!(DATA, *out[0]);
  }

  #[test]
  fn multi_part_decode() {
    const INPUT_1: [u8; 6] = [0xc0, 0x01, 0x02, 0x03, 0x04, 0x05];
    const INPUT_2: [u8; 6] = [0x05, 0x06, 0x07, 0x08, 0x09, 0xc0];
    const DATA: [u8; 10] = [0x01, 0x02, 0x03, 0x04, 0x05, 0x05, 0x06, 0x07, 0x08, 0x09];

    let mut slip = SlipDecoder::new();

    {
      let res = slip.ingest(&mut INPUT_1.as_ref()).unwrap();
      assert!(res.is_empty());
    }

    {
      let res = slip.ingest(&mut INPUT_2.as_ref()).unwrap();
      assert_eq!(res.len(), 1);
      assert_eq!(DATA, *res[0]);
    }
  }

  #[test]
  fn compound_decode() {
    const INPUT: [u8; 13] = [0xc0, 0x01, 0x02, 0x03, 0x04, 0x05, 0xc0, 0x05, 0x06, 0x07, 0x08, 0x09, 0xc0];
    const DATA_1: [u8; 5] = [0x01, 0x02, 0x03, 0x04, 0x05];
    const DATA_2: [u8; 5] = [0x05, 0x06, 0x07, 0x08, 0x09];

    let mut slip = SlipDecoder::new();

    {
      let res = slip.ingest(&INPUT).unwrap();
      assert_eq!(res.len(), 2);
      assert_eq!(DATA_1, *res[0]);
      assert_eq!(DATA_2, *res[1]);
    }
  }
}
