use std::{fmt, string::ToString};

use serde::{
  de::{self, Deserializer, Visitor},
  Deserialize, Serialize,
};
use strum::Display;

#[derive(Debug, Clone, PartialEq, Serialize, Display, Deserialize)]
pub enum ToBoatAction {
  Ping,
  ControlStatusChange(bool),
  SetMotor(f32, f32),
}

#[derive(Debug, Clone, PartialEq, Serialize, Display, Deserialize)]
pub enum FromBoatAction {
  Ping,
  ControlStatusChange(bool),
  SetMotor(f32, f32),
}

#[derive(Debug, Clone, PartialEq, Serialize, Display, Deserialize)]
pub enum Action {
  Tick,
  Render,
  Resize(u16, u16),
  Suspend,
  Resume,
  RequestQuit,
  ConfirmQuit,
  Refresh,
  Error(String),
  RelativeMotorSpeed(i32, i32),
  Help,
  ToBoat(ToBoatAction),
  FromBoat(FromBoatAction),
  CriticalError(String),
  DismissError,
}
