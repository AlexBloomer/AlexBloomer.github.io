pub mod radio_comms {
  include!(concat!(env!("OUT_DIR"), "/radio_comms.rs"));
}

pub mod dtp;
pub mod sliplib;
