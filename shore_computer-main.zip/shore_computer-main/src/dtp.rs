use tracing::info;

pub fn try_decode(packet: &[u8]) -> Option<Vec<u8>> {
  if packet.len() < 7 {
    return None;
  }

  // Take first 2 bytes
  let checksum = u32::from_be_bytes([0, 0, packet[packet.len() - 2], packet[packet.len() - 1]]) as u16;

  let data = &packet[4..packet.len() - 2];

  let calc_checksum = (fnv1a(data) >> 16) as u16;

  if calc_checksum != checksum {
    return None;
  }

  return Some(data.iter().cloned().collect());
}

// This works now
pub fn encode(data: &[u8]) -> Vec<u8> {
  let mut output = Vec::new();

  output.extend([0, 0, 0, 1]);

  output.extend(data);

  output.extend(((fnv1a(data) >> 16) as u16).to_be_bytes());

  return output;
}

// DJB2
fn fnv1a(data: &[u8]) -> u32 {
  let mut hash: u32 = 0x811c9dc5;
  for c in data {
    hash = hash ^ (*c as u32);
    hash = hash.wrapping_mul(0x01000193)
  }

  return hash;
}

mod tests {
  use super::*;

  #[test]
  fn test_simple_fnv1a() {
    let data = b"abc123";
    assert_eq!(fnv1a(data), 0x38b29a05)
  }

  #[test]
  fn test_invalid_decode_packet() {
    let data = b"\x00\x00\x00\x01abc124\x9a\x05";
    let maybe_decode = try_decode(data);
    assert!(maybe_decode.is_none());
  }

  #[test]
  fn test_internal_consistency() {
    let encoded = encode(b"abc123");

    let maybe_decode = try_decode(&encoded);
    assert!(maybe_decode.is_some());
    assert_eq!(maybe_decode.unwrap(), b"abc123");
  }
}
