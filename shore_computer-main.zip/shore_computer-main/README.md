# shore_computer

[![CI](https://github.com//shore-computer/workflows/CI/badge.svg)](https://github.com//shore-computer/actions)

Controller interface for PolyVessel
