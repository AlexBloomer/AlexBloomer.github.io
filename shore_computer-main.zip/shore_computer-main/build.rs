fn main() -> Result<(), Box<dyn std::error::Error>> {
  prost_build::compile_protos(&["./protos/radio_comms.proto"], &["protos/"])?;
  vergen::EmitBuilder::builder().all_build().all_git().emit()?;
  Ok(())
}
